var xmlparser = require('cloud/xml-parser.js');
var removeAccentuation = require('cloud/diacritics.js').remove;
var helpers = require('cloud/helpers.js');
var vehicleModule = require('cloud/vehicle.js');
var _ = require('underscore.js');

var colorMapper = helpers.colorMapper;
var colorHexMapper = helpers.colorHexMapper;

var cargaVeiculosIntegerFields = {
    "Km" : "km",
    "Portas" : "doors",
    "AnoModelo" : "modelYear",
    "Preco" : "price",
    "AnoFabr" : "manufactureYear"
};
var cargaVeiculosDefaultFields = {
    "Placa" : "licensePlate",
    "Codigo" : "vehicleId",
};
var cargaVeiculosImageKeys = {
    "array" : "Fotos",
    "image" : "FotoURL"
};

Parse.Cloud.define("readXML", function(request, response) {

    var url = 'http://www.brdealer.com.br/portais/EXPORT_B0399_399001.xml';

    Parse.Cloud.httpRequest({
        url: url,
        headers: {
            'Content-Type': 'text/xml'
        }
    }).then(function(httpResponse) {
        var xml = xmlparser(httpResponse.text);
        response.success(xml.root);
    },
    function(httpResponse) {
        response.error(httpResponse);
    });
});

Parse.Cloud.define("importObjects", function(request, response) {
    var objectsDictionaries = request.params.objectsDictionaries;
    var compareKey = request.params.compareKey;
    var className = request.params.className;

    var query = new Parse.Query(className);
    query.find().then(function (objects) {
        var newObjects = [];
        var ObjectClass = Parse.Object.extend(className);

        objectsDictionaries.forEach(function (objectDictionary) {
            var shouldCreate = true;
            objects.concat(newObjects).some(function (object) {
                if (object.get(compareKey) == objectDictionary[compareKey]) {
                    shouldCreate = false;
                    return true;
                }
            });
            if (shouldCreate) {
                var newObject = new ObjectClass();
                for (var objectKey in objectDictionary) {
                    newObject.set(objectKey, objectDictionary[objectKey]);
                }
                newObjects.push(newObject);
            }
        });
        return Parse.Object.saveAll(newObjects);

    }).then(function (savedBrands) {
        response.success(savedBrands);
    }, function (error) {
        response.error(error);
    });
});

Parse.Cloud.define("importOtherInfos", function(request, response) {
    var brandsDictionaries = [];
    var modelsDictionaries = [];
    var colorsDictionaries = [];
    var fuelsDictionaries = [];
    var transmissionsDictionaries = [];
    var vehicleTypesDictionaries = [];

    Parse.Cloud.run('readXML').then(function (rootNode) {
        rootNode.children.forEach(function (vehicleNode) {
            var vehicleBrandName;
            var vehicleModelName;

            vehicleNode.children.forEach(function (child) {
                var childName = child.name;
                var childContent = decodeURIComponent(escape(child.content)); //Removes accentuation

                if (childName == "Tipo") {
                    vehicleTypesDictionaries.push({
                        "name": childContent
                    });
                }
                else if (childName == "Marca") {
                    vehicleBrandName = childContent;
                    brandsDictionaries.push({
                        "name": childContent
                    });
                }
                else if (childName == "ModeloVersao") {
                    vehicleModelName = childContent.indexOf(" ") == -1 ? childContent : childContent.substring(0, childContent.indexOf(' '));
                }
                else if (childName == "Combustivel") {
                    fuelsDictionaries.push({
                        "name": childContent
                    });
                }
                else if (childName == "Cambio") {
                    transmissionsDictionaries.push({
                        "name": childContent
                    });
                }
                else if (childName == "Cor") {
                    var colorName = childContent;
                    var colorNameFromMapper = colorMapper[childContent];
                    if (colorNameFromMapper != null) {
                        colorName = colorNameFromMapper;
                    }
                    var colorDictionary = {
                        "name": colorName,
                        "hex": colorHexMapper[colorName]
                    };
                    colorsDictionaries.push(colorDictionary);
                }
            });

            modelsDictionaries.push({
                "name": vehicleModelName,
                "brand": vehicleBrandName
            });
        });
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": brandsDictionaries,
            "className": "Brand",
            "compareKey": "name"
        });
    }).then(function (brands) {
        modelsDictionaries.forEach(function (modelDictionary) {
            brands.some(function (brand) {
                if (brand.get("name") == modelDictionary.brand) {
                    modelDictionary.brand = helpers.pointerMake("Brand", brand.id);
                    return true;
                }
            });
        });
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": modelsDictionaries,
            "className": "Model",
            "compareKey": "name"
        });
    }).then(function (models) {
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": colorsDictionaries,
            "className": "Color",
            "compareKey": "name"
        });
    }).then(function (colors) {
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": fuelsDictionaries,
            "className": "Fuel",
            "compareKey": "name"
        });
    }).then(function (colors) {
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": transmissionsDictionaries,
            "className": "Transmission",
            "compareKey": "name"
        });
    }).then(function (transmissions) {
        return Parse.Cloud.run('importObjects', {
            "objectsDictionaries": vehicleTypesDictionaries,
            "className": "VehicleType",
            "compareKey": "name"
        });
    }).then(function (vehicleTypes) {
        response.success();
    });
});

Parse.Cloud.define("importVehicles", function(request, response) {
    var rootNode;

    var brands;
    var colors;
    var fuels;
    var models;
    var transmissions;
    var vehicleTypes;
    var stores;

    var vehiclesArray = [];

    Parse.Cloud.run('readXML').then(function (rootNodeFromResponse) {
        rootNode = rootNodeFromResponse;
        var brandQuery = new Parse.Query("Brand");
        return brandQuery.find();
    }).then(function (brandsResult) {
        brands = brandsResult;
        var colorQuery = new Parse.Query("Color");
        return colorQuery.find();
    }).then(function (colorsResult) {
        colors = colorsResult;
        var fuelQuery = new Parse.Query("Fuel");
        return fuelQuery.find();
    }).then(function (fuelsResult) {
        fuels = fuelsResult;
        var modelsQuery = new Parse.Query("Model");
        return modelsQuery.find();
    }).then(function (modelsResult) {
        models = modelsResult;
        var transmissionQuery = new Parse.Query("Transmission");
        return transmissionQuery.find();
    }).then(function (transmissionResult) {
        transmissions = transmissionResult;
        var vehicleTypeQuery = new Parse.Query("VehicleType");
        return vehicleTypeQuery.find();
    }).then(function (vehicleTypeResult) {
        vehicleTypes = vehicleTypeResult;
        var storeQuery = new Parse.Query("Store");
        return storeQuery.find();
    }).then(function (storeResult) {
        stores = storeResult;
        console.log(stores);
        var vehicleQuery = new Parse.Query("Vehicle");
        vehicleQuery.limit(10000);
        return vehicleQuery.find();
    }).then(function (vehicles) {
        return Parse.Object.destroyAll(vehicles);
    }).then(function (deletedVehicles) {
        var Vehicle = Parse.Object.extend("Vehicle");
        var vehiclesJSONArray = [];

        rootNode.children.forEach(function (vehicleNode) {
            var vehicle = new Vehicle();

            vehicleNode.children.forEach(function (child) {
                var childName = child.name;
                var childContent = decodeURIComponent(escape(child.content)); //Removes accentuation

                if (cargaVeiculosDefaultFields[childName] != null) {
                    vehicle.set(cargaVeiculosDefaultFields[childName], childContent);
                }
                else if (cargaVeiculosIntegerFields[childName] != null) {
                    vehicle.set(cargaVeiculosIntegerFields[childName], parseInt(childContent));
                }
                else if (childName == "Fotos") {
                    if (child.children.length > 0) {
                        var picturesURLs = [];
                        var pictureNode = child.children[0];
                        picturesURLs.push(pictureNode.content);
                        vehicle.set("picturesURLs", picturesURLs);
                    }
                }
                else {
                    var childContentNormalized = removeAccentuation(childContent.toLowerCase());

                    if (childName == "Tipo") {
                        vehicleTypes.some(function (vehicleType) {
                            var vehicleTypeName = removeAccentuation(vehicleType.get("name"));
                            if (vehicleTypeName.toLowerCase().indexOf(childContentNormalized.toLowerCase()) != -1) {
                                vehicle.set("type", helpers.pointerMake("VehicleType", vehicleType.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "Marca") {
                        brands.some(function (brand) {
                            var brandName = removeAccentuation(brand.get("name"));
                            if (brandName.toLowerCase().indexOf(childContentNormalized.toLowerCase()) != -1) {
                                vehicle.set("brand", helpers.pointerMake("Brand", brand.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "ModeloVersao") {
                        vehicle.set("modelDescription", childContent);
                        models.some(function (model) {
                            var modelName = removeAccentuation(model.get("name"));
                            var modelNameFromVehicle = childContent.indexOf(" ") == -1 ? childContent : childContent.substring(0, childContent.indexOf(' '));
                            if (modelNameFromVehicle == modelName) {
                                vehicle.set("model", helpers.pointerMake("Model", model.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "Combustivel") {
                        fuels.some(function (fuel) {
                            if (fuel.get("name") == childContent) {
                                vehicle.set("fuel", helpers.pointerMake("Fuel", fuel.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "Cambio") {
                        transmissions.some(function (transmission) {
                            if (transmission.get("name") == childContent) {
                                vehicle.set("transmission", helpers.pointerMake("Transmission", transmission.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "Loja") {
                        stores.some(function (store) {
                            if (store.get("storeId") == childContent) {
                                vehicle.set("store", helpers.pointerMake("Store", store.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "Cor") {
                        var colorName = childContent;
                        var colorNameFromMapper = colorMapper[childContent];
                        if (colorNameFromMapper != null) {
                            colorName = colorNameFromMapper;
                        }

                        colors.some(function (color) {
                            if (color.get("name") == colorName) {
                                vehicle.set("color", helpers.pointerMake("Color", color.id));
                                return true; //break
                            }
                        });
                    }
                    else if (childName == "ZeroKm") {
                        var zeroKmLowerCase = childContentNormalized.toLowerCase();
                        if (zeroKmLowerCase == "n") {
                            vehicle.set("zeroKm", false);
                        }
                        else if (zeroKmLowerCase == "s") {
                            vehicle.set("zeroKm", true);
                        }
                    }
                }
            });

            if (vehicle.get("zeroKm") == true) {
                vehicle.set("km", 0);
            }

            vehiclesArray.push(vehicle);
            vehiclesJSONArray.push(vehicleModule.vehicleSummary(vehicle));
        });
        return Parse.Object.saveAll(vehiclesArray);
    }).then(function (savedVehicles) {
        response.success({
            "savedVehicles" : savedVehicles
        });
    }, function (error) {
        response.error(error);
    });
});

//New for others providers;
var xmldoc = require('cloud/xmldoc.js');


var add = function (arr,name,options) {
    var id = arr.length + 1;
    var found = arr.some(function (el) {
      return el.name === name;
    });
    if (!found) {
        arr.push({ id: id, name: name ,options:options});
    }
}

Parse.Cloud.define("readXmlDynamic",function (request, response) {

    var url = request.params.url

    Parse.Cloud.httpRequest({
        url: url,
        headers: {
            'Content-Type': 'text/xml'
        }
    }).then(function(httpResponse) {
        //var xml = xmlparser(httpResponse.text);
        var xml = new xmldoc.XmlDocument(httpResponse.text);
        response.success(xml);
    },
    function(httpResponse) {
        response.error(httpResponse);
    });
});

Parse.Cloud.define("updateObjectInfo",function (request, response) {
    var brands = [];
    var models = [];
    var transmissions = [];
    var colors = [];
    var fuels = [];
    var vehiclesJSONArray = [];
    var arrayOfFunctions = [];

    var providersQuery = new Parse.Query("Providers");
    providersQuery.find().then(
        function(providers){

            var promise = Parse.Promise.as();

            _.each(providers,function (provider) {
                arrayOfFunctions.push(Parse.Cloud.run('readXmlDynamic',{url: provider.get('url')}));
            })

            Parse.Promise.when(arrayOfFunctions).then(
                function (results) {

                    _.each(arguments,function (xml) {
                        var vehicles = xml.children;
                        _.each(vehicles,function(veiculo){
                            var vehicleJson = {};
                            var veiculo = veiculo.children;
                            _.each(veiculo,function (child, index, veiculo) {
                                var childName = child.name.trim();
                                var childContent = child.val.trim();

                                var brandName = '';
                                switch(childName){
                                    case "marca":
                                        var capitalizeFirst = childContent.charAt(0).toUpperCase() + childContent.slice(1).toLowerCase();
                                        add(brands,capitalizeFirst,{});
                                        vehicleJson[childName] = capitalizeFirst;
                                        break;
                                    case "modelo":
                                        var marca = veiculo[6].val.trim();
                                        var formatted = marca.charAt(0).toUpperCase() + marca.slice(1).toLowerCase();
                                        var capitalizeFirst = childContent.charAt(0).toUpperCase() + childContent.slice(1).toLowerCase();
                                        add(models,capitalizeFirst,{"brand":formatted});
                                        vehicleJson[childName] = capitalizeFirst;
                                        break;
                                    case "cambio":
                                        add(transmissions,childContent,{});
                                        vehicleJson[childName] = childContent;
                                        break;
                                    case "cor":
                                        add(colors,childContent,{});
                                        vehicleJson[childName] = childContent;
                                        break;
                                    case "combustivel":
                                        add(fuels,childContent,{});
                                        vehicleJson[childName] = childContent;
                                        break;
                                    case "fotos":
                                            var fotosArray = [];
                                            _.each(child.children,function (foto) {
                                                fotosArray.push(foto.val);
                                            })
                                            vehicleJson[childName] = fotosArray;
                                        break;
                                    default:
                                        vehicleJson[childName] = childContent;
                                }
                            })
                            vehiclesJSONArray.push(vehicleJson);
                        });
                    })

                    Parse.Cloud.run("saveAllObjects",{
                        "length":vehiclesJSONArray.length,
                        "vehiclesJSONArray":vehiclesJSONArray,
                        "brands":brands,
                        "models":models,
                        "transmissions":transmissions,
                        "colors":colors,
                        "fuels":fuels
                    }).then(
                        function (res) {
                            response.success(res);
                        },
                        function (error) {
                            response.error(error);
                        }
                    );
                },function (error) {
                    response.error(error);
                }
            )
        },
        function(error){
            response.error(error);
        }
    )
})

var filterObjectsToSave = function(className,foundObjects,compareObjects){
    var compareObjects = _.map(compareObjects,function (el) {return el.name;});
    var classNameObject = new Parse.Object.extend(className);
    var foundObjectsArray = _.map(foundObjects,function(obj){
            return obj.get("name")
        })
    var objectsTemp = _.difference(compareObjects, foundObjectsArray);
    var objectToSave = [];
    _.each(objectsTemp,function( objectTemp){
        var object = new classNameObject();
        object.set("name", objectTemp);
        objectToSave.push(object);
    })
    return objectToSave;
}

Parse.Cloud.define("saveAllObjects",function (request, response) {

    var vehiclesJSONArray = request.params.vehiclesJSONArray;
    var brands = request.params.brands;
    var models = request.params.models;

    var transmissions = request.params.transmissions;
    var colors = request.params.colors;
    var fuels = request.params.fuels;
    var brandsTemp = [];



    var savedObject = {};

    var fuelQuery = new Parse.Query("Fuel");
    fuelQuery.find().then(function (containedFuels) {
        return Parse.Object.saveAll(filterObjectsToSave("Fuel",containedFuels,fuels)).then(function (fuelObjects) {
            savedObject.fuels = fuelObjects ? _.union(fuelObjects,containedFuels) : containedFuels;

            var transmissionsQuery = new Parse.Query("Transmission");
            return transmissionsQuery.find();
        });
    })
    .then(function (containedTransmissions){
        return Parse.Object.saveAll(filterObjectsToSave("Transmission",containedTransmissions,transmissions)).then(function (transmissionObjects) {
            savedObject.transmissions = transmissionObjects ?_.union(containedTransmissions,transmissionObjects) : containedTransmissions;

            var colorsQuery = new Parse.Query("Color");
            return colorsQuery.find();
        });
    })
    .then(function (containedColors){
        return Parse.Object.saveAll(filterObjectsToSave("Color",containedColors,colors)).then(function (colorsObjects) {
            savedObject.colors = colorsObjects ? _.union(containedColors,colorsObjects) : containedColors;

            var BrandQuery = new Parse.Query("Brand");
            BrandQuery.limit(1000);
            return BrandQuery.find();
        });
    })
    .then(function (containedBrands) {
        return Parse.Object.saveAll(filterObjectsToSave("Brand",containedBrands,brands)).then(function (brandsObject) {
            savedObject.brands = brandsObject ? _.union(containedBrands,brandsObject) : containedBrands;
            brandsTemp = brandsObject ? _.union(containedBrands,brandsObject) : containedBrands;

            var ModelQuery = new Parse.Query("Model");
            ModelQuery.limit(1000);
            ModelQuery.include('brand');
            return ModelQuery.find();
        });
    })
    .then(function (containedModels) {

        _.each(models,function(model){
            _.each(savedObject.brands,function(brand){
                if (brand.get("name") == model.options.brand) {
                    model.brand = helpers.pointerMake("Brand", brand.id);
                    return true;
                }
            })
        })
        var modelObject = new Parse.Object.extend('Model');
        var newObjects =[];
        var results = models.filter(function(model){
            return containedModels.filter(function(containedModel){
                return containedModel.get('name') == model.name;
            }).length == 0
        })

        _.each(results,function (model) {
            var ModelObject = new modelObject();
            ModelObject.set('brand', model.brand);
            ModelObject.set('name', model.name);
            newObjects.push(ModelObject);

        })

        return Parse.Object.saveAll(newObjects).then(function (ModelsObject) {
            savedObject.models = ModelsObject ? _.union(containedModels,ModelsObject) : containedModels;

            var VehicleQuery = new Parse.Query("Vehicle");
            VehicleQuery.limit(10000);
            return VehicleQuery.find();
        });
    })
    .then(function (cars) {

        response.success(vehiclesJSONArray);
    })
})




























