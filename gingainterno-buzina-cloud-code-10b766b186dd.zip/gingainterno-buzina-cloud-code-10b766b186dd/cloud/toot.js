    var helpers = require("cloud/helpers.js");
var _ = require('underscore.js');

var pointerMake = helpers.pointerMake;

var tootSummary = function (toot, colors) {
    var tootJSON = {
        "tootId" : toot.id,
        "minVehicleYear": toot.get("minVehicleYear"),
        "maxVehicleYear": toot.get("maxVehicleYear"),
        "vehiclePrice": toot.get("vehiclePrice"),
        "vehicleKm": toot.get("vehicleKm"),
        "receiveNotification": toot.get("enabled"),
        "geoRadius": toot.get("radius")
    };

    var vehicleModel = toot.get("vehicleModel");

    var vehicleColorsNames = [];
    colors.forEach(function (color) {
        //The phonegap developer asked to encapsulate every color in an object only with the "name" property
        vehicleColorsNames.push({
            "name": color.get("name")
        });
    });
    tootJSON.vehicleColorsNames = vehicleColorsNames;

    if (vehicleModel instanceof Parse.Object) {
        tootJSON.vehicleModelName = vehicleModel.get("name");

        var vehicleBrand = vehicleModel.get("brand");
        if (vehicleBrand instanceof Parse.Object) {
            tootJSON.vehicleBrandName = vehicleBrand.get("name");
        }
    }

    return tootJSON;
}

var getTootResultsQuery = function (toot, colors) {
    var query = new Parse.Query("Vehicle");
    query.greaterThanOrEqualTo("manufactureYear", toot.get("minVehicleYear"));
    query.lessThanOrEqualTo("manufactureYear", toot.get("maxVehicleYear"));
    query.lessThanOrEqualTo("price", toot.get("vehiclePrice"));
    query.lessThanOrEqualTo("km", toot.get("vehicleKm"));

    var vehicleModel = toot.get("vehicleModel");
    if (vehicleModel != null) {
        query.equalTo("model", (vehicleModel instanceof Parse.Object) ? pointerMake("Model", vehicleModel.id) : vehicleModel);
    }

    var colorsPointers = [];
    for (colorIndex in colors) {
        var color = colors[colorIndex];
        var colorPointer = (color instanceof Parse.Object) ? pointerMake("Color", color.id) : pointerMake("Color", color);
        colorsPointers.push(colorPointer);
    }
    if (colorsPointers.length > 0) {
        query.containedIn("color", colorsPointers);
    }
    return query;
};

Parse.Cloud.define("toots", function(request, response) {
    var user = request.user;

    if (user == null) {
        response.error("You must be logged in.");
        return;
    }

    var tootsJSON = [];

    var query = new Parse.Query("Toot");
    query.equalTo("user", pointerMake("_User", user.id));
    query.include("vehicleModel");
    query.include("vehicleModel.brand");
    query.include("vehicleColor");
    query.find().then(function (toots) {
        var promise = Parse.Promise.as();
  		_.each(toots, function(toot) {
            var tootJSON;
    		// For each item, extend the promise with a function to delete it.
    		promise = promise.then(function() {
                return toot.relation("vehicleColors").query().find();
    		}).then(function (colors) {
                tootJSON = tootSummary(toot, colors);

                return getTootResultsQuery(toot, colors).find();
			}).then(function (vehicles) {
                tootJSON.vehiclesCount = vehicles.length;
                tootsJSON.push(tootJSON);
            });
  		});
  		return promise;
    }).then(function () {
        response.success({
            "toots": tootsJSON
        });
    }, function (error) {
        response.error(error);
    });
});

Parse.Cloud.define("saveToot", function(request, response) {
    if (request.user == null) {
        response.error("You must be logged in.");
        return;
    }

    var tootJSON = request.params.toot;
    if (tootJSON == null) {
        response.error("You must provide a toot object.");
        return;
    }
    else {
        var tootKeys = ["vehicleModelId", "minVehicleYear", "maxVehicleYear", "vehicleColorsIds", "vehiclePrice", "vehicleKm", "geoRadius"];
        for (var tootKeyIndex in tootKeys) {
            var key = tootKeys[tootKeyIndex];
            if (tootJSON[key] == null) {
                response.error("Missing toot property: " + key + ".");
                return;
            }
        }
    }

    var tootSummaryJSON;

    var colorsQuery = new Parse.Query("Color");
    colorsQuery.containedIn("objectId", tootJSON.vehicleColorsIds);
    colorsQuery.find().then(function (colors) {
        var Toot = Parse.Object.extend("Toot");
        var toot = new Toot();
        toot.set("vehicleModel", pointerMake("Model", tootJSON.vehicleModelId));
        toot.set("user", pointerMake("_User", request.user.id));
        toot.set("minVehicleYear", tootJSON.minVehicleYear);
        toot.set("maxVehicleYear", tootJSON.maxVehicleYear);
        toot.set("vehiclePrice", tootJSON.vehiclePrice);
        toot.set("vehicleKm", tootJSON.vehicleKm);
        toot.set("radius", tootJSON.geoRadius);
        toot.set("enabled", true);
        toot.relation("vehicleColors").add(colors);
        return toot.save();

    }).then(function (savedToot) {
        response.success({
            "tootId": savedToot.id
        });
    }, function (error) {
        response.error(error);
    });
});

Parse.Cloud.define("deleteToot", function(request, response) {
    var user = Parse.User.current();
    if (user == null) {
        response.error("You must be logged in.");
        return;
    }

    var tootId = request.params.tootId;
    if (tootId == null) {
        response.error("Missing parameter: tootId");
        return;
    }

    var tootQuery = new Parse.Query("Toot");
    tootQuery.get(tootId, {
        success: function(toot) {
            if (toot == null) {
                response.error("Toot not found.");
            }
            else {
                toot.destroy({
                    success: function(toot) {
                        response.success();
                    },
                    error: function(toot, error) {
                        response.error("Error deleting toot: " + error);
                    }
                });
            }
        },
        error: function(error) {
            response.error("Error retrieving toot: " + error);
        }
    });
});

Parse.Cloud.define("tootVehicles", function(request, response) {
    var userLocation = request.params.location;
    var storeId = request.params.storeId;
    var advertisementDate = request.params.advertisementDate;

    var stores;
    var storesJSON = [];
    vehiclesCount = 0;

    var storeQuery = new Parse.Query("Store");

    var userLocationGeoPoint;
    if (userLocation != null) {
        var latitude = userLocation.latitude;
        var longitude = userLocation.longitude;
        userLocationGeoPoint = new Parse.GeoPoint({latitude: latitude, longitude: longitude});
        storeQuery.near("location", userLocationGeoPoint);
    }

    if (storeId != null) {
        storeQuery.equalTo("objectId", storeId);
    }

    storeQuery.find().then(function (storeResult) {
        stores = storeResult;

        var tootId = request.params.tootId;
        if (tootId == null) {
            var tootJSON = request.params.toot;
            if (tootJSON == null) {
                response.error("You must provide a tootId or a toot JSON object.");
                return;
            }
            else {
                var colorsQuery = new Parse.Query("Color");
                colorsQuery.containedIn("objectId", tootJSON.vehicleColorsIds);
                colorsQuery.find().then(function (colors) {
                    var Toot = Parse.Object.extend("Toot");
                    var toot = new Toot();
                    toot.set("vehicleModel", pointerMake("Model", tootJSON.vehicleModelId));
                    toot.set("minVehicleYear", tootJSON.minVehicleYear);
                    toot.set("maxVehicleYear", tootJSON.maxVehicleYear);
                    toot.set("vehiclePrice", tootJSON.vehiclePrice);
                    toot.set("vehicleKm", tootJSON.vehicleKm);

                    var vehicleQuery = getTootResultsQuery(toot, tootJSON.vehicleColorsIds);
                    vehicleQuery.include("model");
                    vehicleQuery.include("model.brand");
                    vehicleQuery.include("color");

                    if (storeId != null) {
                        vehicleQuery.equalTo("store", helpers.pointerMake("Store", storeId));
                    }

                    return vehicleQuery.find();
                }).then(function (vehicles) {
                    vehiclesCount += vehicles.length;
                    stores.forEach(function (store) {
                        var phone = store.get("phone");

                        var storeJSON = {
                            "storeId": store.id,
                            "phone": phone == null ? "" : phone,
                            "vehicles": []
                        };

                        var storeLocation = store.get("location");
                        if (storeLocation != null) {
                            storeJSON.latitude = storeLocation.latitude;
                            storeJSON.longitude = storeLocation.longitude;
                            if (userLocationGeoPoint != null) {
                                storeJSON.distance = userLocationGeoPoint.kilometersTo(storeLocation);
                            }
                        }

                        vehicles.forEach(function (vehicle) {
                            var vehicleStorePointer = vehicle.get("store");
                            if (vehicleStorePointer != null && vehicleStorePointer.id == store.id) {
                                var vehicleImages = vehicle.get("picturesURLs");
                                var vehicleImage = "";
                                if (vehicleImages != null && vehicleImages.length > 0) {
                                    vehicleImage = vehicleImages[0];
                                }

                                var vehicleJSON = {
                                    "brand": vehicle.get("model").get("brand").get("name"),
                                    "model": vehicle.get("model").get("name"),
                                    "modelDescription": vehicle.get("modelDescription"),
                                    "year": vehicle.get("modelYear"),
                                    "km": vehicle.get("km"),
                                    "color": vehicle.get("color").get("name"),
                                    "price": vehicle.get("price"),
                                    "imageURL": vehicleImage
                                };
                                storeJSON.vehicles.push(vehicleJSON);
                            }
                        });

                        if (storeJSON.vehicles.length > 0) {
                            storesJSON.push(storeJSON);
                        }
                    });

                    var query = new Parse.Query("Advertisement");
                    query.limit(Math.floor(vehiclesCount/3));
                    query.ascending("updateAt");
                    query.equalTo("type","searchCarResults");
                    if (advertisementDate && advertisementDate!="") {
                        query.greaterThan("updatedAt", new Date(advertisementDate));
                    };

                    return query.find();

                }, function (error) {
                    response.error(error);
                })
                .then(function (advertisements) {

                    var advertisementsJSON = [];
                    advertisements.forEach(function (advertisement) {
                        var advertisementImage = advertisement.get("image");
                        if (advertisementImage != null ) {
                            var advertisementJSON = {
                                "imageURL": advertisementImage.url(),
                                "targetURL": advertisement.get("targetURL"),
                                "updatedAt": advertisement.updatedAt
                            }
                            advertisementsJSON.push(advertisementJSON);
                        }
                    });

                    response.success({
                        "stores": storesJSON,
                        "advertisements": advertisementsJSON,
                        "advertisementDate": advertisementDate,
                        "date": new Date(),
                        "count": Math.floor(vehiclesCount/3)
                    });

                }, function (error) {
                    response.error(error);
                });
            }
        }
        else {
            var toot;

            var tootQuery = new Parse.Query("Toot");
            tootQuery.get(tootId).then(function (tootRetrieved) {
                toot = tootRetrieved;
                return toot.relation("vehicleColors").query().find();
            }).then(function (colors) {
                var vehicleQuery = getTootResultsQuery(toot, colors);
                vehicleQuery.include("model");
                vehicleQuery.include("model.brand");
                vehicleQuery.include("color");

                if (storeId != null) {
                    vehicleQuery.equalTo("store", helpers.pointerMake("Store", storeId));
                }

                return vehicleQuery.find();
            }).then(function (vehicles) {
                stores.forEach(function (store) {
                    var phone = store.get("phone");
                    var storeJSON = {
                        "storeId": store.id,
                        "phone": phone == null ? "" : phone,
                        "vehicles": []
                    };

                    var storeLocation = store.get("location");
                    if (storeLocation != null) {
                        storeJSON.latitude = storeLocation.latitude;
                        storeJSON.longitude = storeLocation.longitude;
                        if (userLocationGeoPoint != null) {
                            storeJSON.distance = userLocationGeoPoint.kilometersTo(storeLocation);
                        }
                    }

                    vehicles.forEach(function (vehicle) {
                        var vehicleStorePointer = vehicle.get("store");
                        if (vehicleStorePointer != null && vehicleStorePointer.id == store.id) {
                            var vehicleImages = vehicle.get("picturesURLs");
                            var vehicleImage = "";
                            if (vehicleImages != null && vehicleImages.length > 0) {
                                vehicleImage = vehicleImages[0];
                            }

                            var vehicleJSON = {
                                "brand": vehicle.get("model").get("brand").get("name"),
                                "model": vehicle.get("model").get("name"),
                                "modelDescription": vehicle.get("modelDescription"),
                                "year": vehicle.get("modelYear"),
                                "km": vehicle.get("km"),
                                "color": vehicle.get("color").get("name"),
                                "price": vehicle.get("price"),
                                "imageURL": vehicleImage
                            };
                            storeJSON.vehicles.push(vehicleJSON);
                        }
                    });

                    if (storeJSON.vehicles.length > 0) {
                        storesJSON.push(storeJSON);
                    }
                });

                response.success({
                    "stores": storesJSON
                });

            }, function (error) {
                response.error(error);
            });
        }
    });
});

Parse.Cloud.define("enableToot", function(request, response) {
    var user = Parse.User.current();
    if (user == null) {
        response.error("You must be logged in.");
        return;
    }

    var tootId = request.params.tootId;
    if (tootId == null) {
        response.error("Missing parameter: tootId");
        return;
    }

    var tootQuery = new Parse.Query("Toot");
    tootQuery.get(tootId, {
        success: function(toot) {
            if (toot == null) {
                response.error("Toot not found.");
            }
            else {
                toot.set("enabled", true);
                toot.save({
                    success: function(toot) {
                        response.success();
                    },
                    error: function(toot, error) {
                        response.error("Error enabling toot: " + error);
                    }
                });
            }
        },
        error: function(error) {
            response.error("Error retrieving toot: " + error);
        }
    });
});

Parse.Cloud.define("disableToot", function(request, response) {
    var user = Parse.User.current();
    if (user == null) {
        response.error("You must be logged in.");
        return;
    }

    var tootId = request.params.tootId;
    if (tootId == null) {
        response.error("Missing parameter: tootId");
        return;
    }

    var tootQuery = new Parse.Query("Toot");
    tootQuery.get(tootId, {
        success: function(toot) {
            if (toot == null) {
                response.error("Toot not found.");
            }
            else {
                toot.set("enabled", false);
                toot.save({
                    success: function(toot) {
                        response.success();
                    },
                    error: function(toot, error) {
                        response.error("Error disabling toot: " + error);
                    }
                });
            }
        },
        error: function(error) {
            response.error("Error retrieving toot: " + error);
        }
    });
});
