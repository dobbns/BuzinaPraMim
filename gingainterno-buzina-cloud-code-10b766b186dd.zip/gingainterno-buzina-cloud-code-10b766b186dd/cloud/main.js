var xmlparser = require('cloud/xml-parser.js');
var removeAccentuation = require('cloud/diacritics.js').remove;
var helpers = require('cloud/helpers.js');

var pointerMake = helpers.pointerMake;

require('cloud/vehicle.js');
require('cloud/toot.js');
require('cloud/user.js');
require('cloud/xml-importer.js');

Parse.Cloud.define("home", function(request, response) {
    var type = "";
    if(request.params.type && request.params.type != "" ){
        type = request.params.type;
    } else {
        type = "home";
    }

    var query = new Parse.Query("Advertisement");
    query.limit(100);
    query.equalTo("type",type);
    query.descending("createdAt");
    query.find().then(function (advertisements) {
        var advertisementsJSON = [];
        advertisements.forEach(function (advertisement) {
            var advertisementImage = advertisement.get("image");
            if (advertisementImage != null) {
                var advertisementJSON = {
                    "imageURL": advertisementImage.url(),
                    "targetURL": advertisement.get("targetURL")
                }
                advertisementsJSON.push(advertisementJSON);
            }
        });
        response.success({
            "advertisements": advertisementsJSON
        });
    }, function (error) {
        response.error(error);
    });
});
