var helpers = require("cloud/helpers.js");
var _ = require('underscore.js');

Parse.Cloud.define("brands", function(request, response) {
	var brandQuery = new Parse.Query("Brand");
	brandQuery.ascending("name");
	var advertisementQuery = new Parse.Query("Advertisement");
	// brandQuery.find({
	// 	success: function (brands) {
	// 		var brandsJSON = [];

	// 		for (var brandIndex in brands) {
	// 			var brand = brands[brandIndex];

	// 			var brandJSON = {
	// 				"brandId": brand.id,
	// 				"name": brand.get("name")
	// 			};

	// 			brandsJSON.push(brandJSON);
	// 		}
	// 		response.success({
	// 			"brands" : brandsJSON
	// 		});
	// 	},
	// 	error: function (error) {
	// 		response.error(error);
	// 	}
	// });

	var  brandsJSON = [];
	brandQuery.find().then(function (brands) {
		var promise = Parse.Promise.as();
		_.each(brands, function(brand) {
			var brandJSON;

			promise = promise.then(function() {
					advertisementQuery.equalTo("sponsorBrand",brand.get("name"))
					return advertisementQuery.first();
				}).then(function (advertisement) {


						brandJSON = {
							"brandId": brand.id,
							"name": brand.get("name"),

						};

						if (advertisement != null){
							advertisementImage = advertisement.get("image");
							advertisementBtnImage = advertisement.get("btnImage");
							brandJSON.sponsor = {
								"imageURL": advertisementImage.url(),
								"targetURL": advertisement.get("targetURL"),
								"btnImage": advertisementBtnImage.url()
							};
						}

					brandsJSON.push(brandJSON);
				});
		});
		return promise;
	}).then(function () {
		response.success({
			"brands": brandsJSON
		});
	}, function (error) {
		response.error(error);
	});
});

Parse.Cloud.define("models", function(request, response) {
	var brandId = request.params.brandId;

	if (brandId == null) {
		response.error("Missing parameter: brandId");
		return;
	}

	var modelQuery = new Parse.Query("Model");
	var advertisementQuery = new Parse.Query("Advertisement");

	modelQuery.equalTo("brand", helpers.pointerMake("Brand", brandId));
	modelQuery.ascending("name");
	// modelQuery.find({
	// 	success: function (models) {
	// 		var modelsJSON = [];

	// 		for (var modelIndex in models) {
	// 			var model = models[modelIndex];

	// 			var modelJSON = {
	// 				"modelId": model.id,
	// 				"name": model.get("name")
	// 			};

	// 			modelsJSON.push(modelJSON);
	// 		}
	// 		response.success({
	// 			"models" : modelsJSON
	// 		});
	// 	},
	// 	error: function (error) {
	// 		response.error(error);
	// 	}
	// });
	var  modelsJSON = [];
	modelQuery.find().then(function (models) {
		var promise = Parse.Promise.as();
		_.each(models, function(model) {
			var modelJSON;

			promise = promise.then(function() {
					advertisementQuery.equalTo("sponsorModel",model.get("name"))
					return advertisementQuery.first();
				}).then(function (advertisement) {


						modelJSON = {
							"modelId": model.id,
							"name": model.get("name"),

						};

						if (advertisement != null){
							advertisementImage = advertisement.get("image");
							advertisementBtnImage = advertisement.get("btnImage");
							modelJSON.sponsor = {
								"imageURL": advertisementImage.url(),
								"targetURL": advertisement.get("targetURL"),
								"btnImage": advertisementBtnImage.url()
							};
						}

					modelsJSON.push(modelJSON);
				});
		});
		return promise;
	}).then(function () {
		response.success({
			"models": modelsJSON
		});
	}, function (error) {
		response.error(error);
	});



});

Parse.Cloud.define("otherOptions", function(request, response) {
	var modelId = request.params.modelId;

	if (modelId == null) {
		response.error("Missing parameter: modelId");
		return;
	}

	var kmInterval;
	var priceInterval;
	var yearInterval;

	Parse.Config.get().then(function(config) {
		kmInterval = config.get("kmInterval");
		priceInterval = config.get("priceInterval");
		yearInterval = config.get("yearInterval");

		var vehicleQuery = new Parse.Query("Vehicle");
		vehicleQuery.equalTo("model", helpers.pointerMake("Model", modelId));
		return vehicleQuery.find();
	}, function(error) {
		response.error("Error retrieving about text.");
	}).then(function (vehicles) {
		if (vehicles.length == 0) {
			response.error("No vehicles found");
			return;
		}

		var minYear = Number.MAX_VALUE;
		var maxYear = Number.MIN_VALUE;

		var minKm = Number.MAX_VALUE;
		var maxKm = Number.MIN_VALUE;

		var minPrice = Number.MAX_VALUE;
		var maxPrice = Number.MIN_VALUE;

		var colorsIds = [];

		for (var vehicleIndex in vehicles) {
			var vehicle = vehicles[vehicleIndex];

			var vehicleYear = vehicle.get("manufactureYear");
			if (vehicleYear < minYear) {
				minYear = vehicleYear;
			}
			if (vehicleYear > maxYear) {
				maxYear = vehicleYear;
			}

			var vehicleKm = vehicle.get("km");
			if (vehicleKm < minKm) {
				minKm = vehicleKm;
			}
			if (vehicleKm > maxKm) {
				maxKm = vehicleKm;
			}

			var vehiclePrice = vehicle.get("price");
			if (vehiclePrice < minPrice) {
				minPrice = vehiclePrice;
			}
			if (vehiclePrice > maxPrice) {
				maxPrice = vehiclePrice;
			}

			var vehicleColorId = vehicle.get("color").id;
			if (colorsIds.indexOf(vehicleColorId) == -1) {
				colorsIds.push(vehicleColorId);
			}
		}

		minKm += kmInterval - (minKm % kmInterval);
		maxKm += kmInterval - (maxKm % kmInterval);

		minPrice += priceInterval - (minPrice % priceInterval);
		maxPrice += priceInterval - (maxPrice % priceInterval);

		var colorsQuery = new Parse.Query("Color");
		colorsQuery.containedIn("objectId", colorsIds);
		colorsQuery.find({
			success: function (colors) {
				var colorsJSON = [];

				for (colorIndex in colors) {
					var color = colors[colorIndex];
					var colorJSON = {
						"colorId": color.id,
						"hex": color.get("hex"),
						"name": color.get("name")
					}
					colorsJSON.push(colorJSON);
				}

				var responseJSON = {
					"options" : {
						"colors": colorsJSON,
						"minKm": minKm,
						"maxKm": maxKm,
						"kmInterval": kmInterval,
						"minYear": minYear,
						"maxYear": maxYear,
						"yearInterval": yearInterval,
						"minPrice": minPrice,
						"maxPrice": maxPrice,
						"priceInterval": priceInterval
					}
				}
				response.success(responseJSON);
			},
			error: function (error) {
				response.error("Error retrieving colors - " + error.message);
			}
		});
	});
});

var vehicleSummary = function (vehicle) {
	var vehicleJSON = {
		"vehicleId" : vehicle.id,
		"manufactureYear": vehicle.get("manufactureYear"),
		"km": vehicle.get("km"),
		"price": vehicle.get("price")
	}

	var brand = vehicle.get("brand");
	var model = vehicle.get("model");
	var color = vehicle.get("color");
	if (brand instanceof Parse.Object) {
		vehicleJSON.brandName = brand.get("name");
	}
	if (model instanceof Parse.Object) {
		vehicleJSON.modelName = model.get("name");
	}
	if (color instanceof Parse.Object) {
		vehicleJSON.colorName = color.get("name");
	}

	var store = vehicle.get("store");
	if (store instanceof Parse.Object) {
		vehicleJSON.store.phone = store.get("phone");

		var storeLocation = store.get("location");
		if (storeLocation != null) {
			vehicleJSON.store.location = {
				"latitude": location.latitude,
				"longitude": location.longitude
			};
		}
	}

	var imagesURLs = vehicle.get("picturesURLs");
	if (imagesURLs != null && imagesURLs.length > 0) {
		vehicleJSON.imageURL = imagesURLs[0];
	}

	return vehicleJSON;
}

module.exports.vehicleSummary = vehicleSummary;
