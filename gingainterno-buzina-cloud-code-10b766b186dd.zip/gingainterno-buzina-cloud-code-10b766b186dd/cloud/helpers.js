module.exports.pointerMake = function (className, objectId) {
    return {
        __type: "Pointer",
        className: className,
        objectId: objectId
    };
};

module.exports.normalizedPhone = function (phone) {
    if (phone == null || !(phone instanceof String)) return "";

    var phoneNormalized = phone.replace("(", "");
    phoneNormalized = phoneNormalized.replace(")", "");
    phoneNormalized = phoneNormalized.replace("-", "");
    phoneNormalized = phoneNormalized.replace(" ", "");
    return phoneNormalized;
};

module.exports.colorMapper = {
    "vermelha": "Vermelho",
    "branca": "Branco",
    "preta": "Preto",
    "amarela": "Amarelo"
}

module.exports.colorHexMapper = {
    "Cinza": "#808080",
    "Vermelho": "#C51111",
    "Azul": "#3F8CD9",
    "Prata": "#D3D7DB",
    "Amarelo": "#F8BD09",
    "Laranja": "#E18134",
    "Preto": "#000000",
    "Branco": "#FFFFFF"
}
