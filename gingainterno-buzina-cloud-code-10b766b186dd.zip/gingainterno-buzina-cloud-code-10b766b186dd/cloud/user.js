Parse.Cloud.define("login", function(request, response) {
    var username = request.params.username;
    var password = request.params.password;

    Parse.User.logIn(username, password, {
        success: function(user) {
            response.success({
                "sessionToken": user.get("sessionToken")
            });
        },
        error: function(user, error) {
            response.error(error);
        }
    });
});

Parse.Cloud.define("logout", function(request, response) {
    if (request.user == null) {
        response.success;
    }
    else {
        Parse.User.logOut();
        response.success();
    }
});

Parse.Cloud.define("profile", function(request, response) {
    var user = request.user;
    if (user == null) {
        response.error("User not logged in.");
    }
    else {
        response.success({
            "name": user.get("name") ? user.get("name") : "",
            "email": user.get("email")
        });
    }
});

Parse.Cloud.define("register", function(request, response) {
    var name = request.params.name;
    var email = request.params.email;
    var password = request.params.password;

    if (name == null) {
        response.error("Missing parameter: name");
        return;
    }

    var user = new Parse.User();
    user.set("username", email);
    user.set("password", password);
    user.set("email", email);
    user.set("name", name);
    user.signUp(null, {
        success: function(user) {
            response.success({
                "sessionToken": user.get("sessionToken")
            });
        },
        error: function(user, error) {
            response.error("Error registering user: " + error.message);
        }
    });
});

Parse.Cloud.define("facebookLogin", function(request, response) {
    var name = request.params.name;
    var email = request.params.email;
    var facebookAccessToken = request.params.accessToken;
    var facebookId = request.params.facebookId;
    Parse.Cloud.useMasterKey();
    var userQuery = new Parse.Query("User");
    userQuery.equalTo("email", email);
    userQuery.find().then(function(users) {
        if (users.length > 0) {
            var user = users[0];
            user.set("facebookId", facebookId);
            user.set("facebookAccessToken", facebookAccessToken);
            user.save({
                success: function(user) {
                    Parse.User.logIn(user.get("username"), facebookId, {
                        success: function(user) {
                            response.success({
                                "sessionToken": user.get("sessionToken")
                            });
                        },
                        error: function(user, error) {
                            response.error("Error logging in user: " + error.message + "  " +user.get("username")+ "  " +facebookId) ;
                        }
                    });
                },
                error: function(user, error) {
                    response.error("Error associating accounts." + error.message);
                }
            });
        }
        else {
            var user = new Parse.User();
            user.set("username", email);
            user.set("email", email);
            user.set("name", name);
            user.set("facebookId", facebookId);
            user.set("facebookAccessToken", facebookAccessToken);
            user.set("password", facebookId);
            user.signUp(null, {
                success: function(user) {
                    response.success({
                        "sessionToken": user.get("sessionToken")
                    });
                },
                error: function(user, error) {
                    response.error("Error registering user: " + error.message);
                }
            });
        }
    })
});

Parse.Cloud.define("passRecover",function(request, response) {

    Parse.User.requestPasswordReset(request.params.email, {
        success: function(res) {
            response.success({
               "success" : true
            });
        },
        error: function(error) {
            response.error({
                "error":error.code,
                "message":error.message
            });
        }
    });
});


